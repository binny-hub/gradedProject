--insert into role (role_id,name) values (1, 'ADMIN');

--insert into User (user_id, password,username) values (1,'$2a$12$uir4L2hC7skcJ6u/UqiBZejcX2yZZOpyxBUnq3FPnH/AwP4xmSQlu','admin');
--insert into user (user_id, password,username) values (2, '$2a$12$xwWyul08szaAixB7JNUI3eqL6z6aT8rRexLTMGAERC0fyBaa.OcIu', 'user1');
--insert into users_roles (user_id,role_id) values (1,1);
--insert into users_roles(user_id, role_id) values(2,2);


insert into roles (role_id,name) values (1,'ADMIN');

insert into user (user_id,password,username) values (1,'$2a$12$r5htAEPHde1FgovdMWFCw.1Wj6KIF2972A74d9Z3HKsqjc13BEGpK','ujjawal');

insert into users_roles (user_id,role_id) values (1,1);